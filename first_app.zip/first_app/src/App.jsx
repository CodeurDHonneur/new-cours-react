import { BrowserRouter, Routes, Route, Navigate  } from "react-router-dom";
import Header from "./header.jsx";
import Home from "./pages/home";
import Calcul from "./pages/about";
import Liste from "./pages/liste";
import Operation from "./pages/operation";
import NotFound from "./pages/NotFound";
import Dashboard from "./pages/Dashboard";
import Profil from "./pages/Profil";
import Parametres from "./pages/Parametres";

function App() {
  return (
    <BrowserRouter>
      <Header />
      
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/calcul" element={<Calcul />} />
        <Route path="/liste" element={<Liste />} />
        <Route path="/operation/:id" element={<Operation />} />
        <Route path="*" element={<NotFound />} />
        <Route path="/dashboard" element={<Dashboard />}>
        <Route index element={<Navigate to="profil" />} />
          <Route path="profil" element={<Profil />} />
          <Route path="parametres" element={<Parametres />} />
        </Route>
      </Routes>
    </BrowserRouter>
    
  );
}

export default App;
