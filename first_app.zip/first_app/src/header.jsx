import { NavLink } from "react-router-dom";

function Header() {
  const linkStyle = ({ isActive }) => ({
    margin: "0 10px",
    textDecoration: "none",
    color: isActive ? "tomato" : "black",
  });

  return (
    <div className="">
      <nav>
        <NavLink to="/" style={linkStyle}>Accueil</NavLink>
        <NavLink to="/calcul" style={linkStyle}>Calculatrice</NavLink>
        <NavLink to="/liste" style={linkStyle}>Liste</NavLink>
        <NavLink to="/dashboard" style={linkStyle}>Dashboard</NavLink>
      </nav>

    </div>

  );
}

export default Header;
