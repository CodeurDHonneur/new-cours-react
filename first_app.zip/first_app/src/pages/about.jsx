import { useState } from 'react'
import {Link } from 'react-router-dom';
export default function Calcul() {
  // Partie 1 : Initialisation de l'état avec useState
  let [compteur, setCompteur] = useState(1);

  // Partie 2 : Définition du comportement handleClick
  const handleClick = () => {
    console.log("compteur avant:", compteur);
    setCompteur(compteur + 1); // mise à jour correcte de l'état
    console.log("compteur après:", compteur); // ATTENTION : cette valeur ne change pas immédiatement
  };

  // Partie 3 : Rendu JSX du composant
  return (
    <div>
      <hr />
      <h1>Compteur : {compteur}</h1>
      <button onClick={handleClick}>Incrémenter</button>
      <div className="calculator">
      <div className="display"></div>
      <div className="buttons">
        <button >1</button>
        <button >2</button>
        <button >3</button>
        <button >+</button>
        <button >4</button>
        <button >5</button>
        <button >6</button>
        <button >-</button>
        <button >7</button>
        <button >8</button>
        <button >9</button>
        <button >*</button>
        <button >0</button>
        <button >=</button>
        <button >/</button>
        <button >C</button>
      </div>
    </div> 
    </div>
  );
}
