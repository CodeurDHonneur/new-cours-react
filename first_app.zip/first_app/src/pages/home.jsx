import { useState } from 'react'
import reactLogo from '../assets/react.svg'
import viteLogo from '/vite.svg'
import '../App.css'

function Home() {
  const [count, setCount] = useState(0)

  return (
    <>
    <hr />
      <div className='header'>
        {/* <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a> */}
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
        <h1>Hello world 🚀🚀🚀</h1>
      </div>

      <div className="card">
        <ul className='list'>
          <li>✔️ Grande communauté et écosystème </li>
          <li>✔️ Flexibilité (choix des outils)</li>
          <li>✔️ Performances élevées (Virtual DOM)  </li>
          <li>❌ Nécessite des outils externes pour être complet</li>
          <li>❌ JSX peut être difficile au début </li>
        </ul>
      </div>
      
    </>
  )
}

export default Home
