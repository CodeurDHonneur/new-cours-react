function Parametres() {
    return <h2>Page Paramètres</h2>;
  }
  export default Parametres;