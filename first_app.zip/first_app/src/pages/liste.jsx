import { useState, useEffect } from "react";
import { Link } from 'react-router-dom';

function Liste() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // Simuler une requête API
    setTimeout(() => {
        setUsers([
            {
              id: 1,
              name: "Alice",
              operations: [
                { expression: "2 + 3", result: 2 + 3 },
                { expression: "4 * 5", result: 4 * 5 },
                { expression: "10 - 2", result: 10 - 2 },
              ],
            },
            {
              id: 2,
              name: "Bob",
              operations: [
                { expression: "7 - 1", result: 7 - 1 },
                { expression: "8 / 2", result: 8 / 2 },
                { expression: "3 * 3", result: 3 * 3 },
              ],
            },
            {
              id: 3,
              name: "Charlie",
              operations: [
                { expression: "5 + 5", result: 5 + 5 },
                { expression: "6 * 2", result: 6 * 2 },
                { expression: "12 - 4", result: 12 - 4 },
              ],
            },
          ]);          
    }, 500);
  }, []);

  return (
    <div>
      <hr />
      <h1>Liste des utilisateurs</h1>
      <ul style={{ 
        listStyle: "none",
        padding: "0" ,
        display: "flex",
        flexWrap: "wrap",
        alignItems: "center",
        justifyContent: "center",
        gap: "25px",
        }}>
        {users.map((user) => (
        //   <li key={user.id}>Nom : {user.name}</li>
          <li key={user.id} 
          style={{
            backgroundColor: "#fff",
            marginBottom: "0.5rem",
            padding: "0.75rem",
            borderRadius: "6px",
            border: "1px solid #ddd",
            color: "black",
          }}
          >
            <Link to={`/operation/${user.id}`} style={{ color: "black", fontWeight: "bold" }}>Nom : {user.name}</Link>
        </li>
        ))}
      </ul>
    </div>
  );
}

export default Liste;
