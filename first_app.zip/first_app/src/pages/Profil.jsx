function Profil() {
    return <h2>Page Profil</h2>;
  }
  export default Profil;