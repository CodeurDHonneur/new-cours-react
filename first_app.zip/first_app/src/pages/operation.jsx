import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";

function Operation() {
  const { id } = useParams();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const allUsers = [
      {
        id: 1,
        name: "Alice",
        operations: [
          { expression: "2 + 3", result: 5 },
          { expression: "4 * 5", result: 20 },
          { expression: "10 - 2", result: 8 },
        ],
      },
      {
        id: 2,
        name: "Bob",
        operations: [
          { expression: "7 - 1", result: 6 },
          { expression: "8 / 2", result: 4 },
          { expression: "3 * 3", result: 9 },
        ],
      },
      {
        id: 3,
        name: "Charlie",
        operations: [
          { expression: "5 + 5", result: 10 },
          { expression: "6 * 2", result: 12 },
          { expression: "12 - 4", result: 8 },
        ],
      },
    ];

    const foundUser = allUsers.find((u) => u.id === parseInt(id));
    setUser(foundUser);
  }, [id]);

  if (!user) {
    return <p style={{ padding: "1rem", color: "red" }}>Utilisateur non trouvé...</p>;
  }

  return (
    <div style={{ maxWidth: "600px", margin: "0 auto", padding: "1rem" }}>
      <h1 style={{ textAlign: "center", color: "#333" }}>
        Opérations de {user.name}
      </h1>
      <div
        style={{
          backgroundColor: "#f5f5f5",
          borderRadius: "8px",
          padding: "1rem",
          boxShadow: "0 0 8px rgba(0,0,0,0.1)",
        }}
      >
        <ul style={{ listStyle: "none", padding: 0 }}>
          {user.operations.map((op, index) => (
            <li
              key={index}
              style={{
                backgroundColor: "#fff",
                marginBottom: "0.5rem",
                padding: "0.75rem",
                borderRadius: "6px",
                border: "1px solid #ddd",
                color: "black",
              }}
            >
              <strong>{op.expression}</strong> =  {" "}
              <span style={{ color: "#2e7d32", fontWeight: "bold" }}> {op.result}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Operation;
