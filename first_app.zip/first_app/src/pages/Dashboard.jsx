import { Outlet, Link } from 'react-router-dom';

function Dashboard() {
  return (
    <div>
      <hr />
      <nav style={{ 
        position: "absolute",
        backgroundColor: "#989898de",
        Color: "#fff",
        paddingBlock: "25px " ,
        paddingInline: "10px" ,
        display: "flex",
        flexWrap: "wrap",
        borderRadius: "10px",
        alignItems: "start",
        flexDirection: "column",
        gap: "15px",
        }}>
        <Link to="profil">Profil</Link> 
         <Link to="parametres">Paramètres</Link>
      </nav>
      <Outlet /> {/* Ici s'affichent les sous-pages */}
    </div>
  );
}

export default Dashboard;